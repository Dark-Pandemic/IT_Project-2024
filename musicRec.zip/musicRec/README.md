# Flask Spotify Recommendation App

This is a Flask web application that recommends Spotify playlists based on user emotions.

## Prerequisites

- Python 3.x
- Virtual environment (optional but recommended)
- Flask
- Spotipy

## Setup Instructions

1. **Clone the Repository:**

   ```bash
   git clone https://github.com/username/repository-name.git
   cd repository-name
Create and Activate a Virtual Environment:

Windows:

bash
Copy code
python -m venv venv
.\venv\Scripts\activate
macOS/Linux:

bash
Copy code
python3 -m venv venv
source venv/bin/activate
Install Dependencies:

bash
Copy code
pip install -r requirements.txt
Run the Application:

bash
Copy code
python app.py
Access the App in Your Browser:

Open http://localhost:8888 in your browser.